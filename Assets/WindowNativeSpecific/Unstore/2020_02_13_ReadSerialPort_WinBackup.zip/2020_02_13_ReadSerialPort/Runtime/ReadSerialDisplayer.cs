﻿using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class ReadSerialDisplayer : MonoBehaviour
{
    //public OpenSerialPortAtStart m_serialPort;
    //public Text m_serialPortName;
    //public Text m_messageDisplayer;
    //public InputField m_messageToSend;

    ////public void Start()
    ////{
    ////    ListenToSerial();
    ////}
    ////public void ListenToSerial() {
    ////    if (m_serialPort) {
    ////        m_serialPortName.text = m_serialPort.m_communication.m_setter.GetPortName();
    ////        m_serialPort..AddListener(DisplayMessage);
    ////    }
    ////}

    ////private void DisplayMessage(TimedMessage arg0)
    ////{
    ////    m_messageDisplayer.text = arg0.m_message;
    ////}

    //public void SendMessage() {
    //    m_serialPort.m_communication.AddToSendMessage( m_messageToSend.text);
    //}
}
